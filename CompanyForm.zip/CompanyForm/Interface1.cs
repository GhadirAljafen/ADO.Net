﻿
using System.Windows.Forms;
namespace CompanyForm
{
    interface IConnection
    {
      //  void DatabaseConnection(string query);
        void DisplayAll(DataGridView dataGrid);
    }
}
